# TriCam AI

A CameraX-based Android camera app prototype for Samsung Galaxy Note 10+ Snapdragon (SM-N975U1 / Android 12).

## Modes
- S — Samsung-inspired camera UI/profile
- G — Pixel-inspired camera UI/profile
- Apple — iPhone-inspired camera UI/profile

These modes are original implementations and do not contain proprietary Samsung, Google, or Apple source code.

## Current build
- CameraX preview and photo capture
- Front/back camera switching
- Safe zoom clamping to the actual camera zoom range
- Flash toggle
- Photos saved to `Pictures/TriCamAI`
- Style-specific capture filenames
- GitHub Actions workflow for APK builds

## Next development stage
1. Add real mode-specific UI layouts.
2. Add Camera2 controls for exposure, white balance and focus where supported.
3. Add original HDR/bracketing pipeline.
4. Add original night multi-frame pipeline.
5. Add portrait depth/segmentation pipeline.
6. Tune profiles specifically for SM-N975U1.

## Important
The app intentionally does not copy proprietary algorithms. The goal is a similar user experience and independently implemented image processing.
