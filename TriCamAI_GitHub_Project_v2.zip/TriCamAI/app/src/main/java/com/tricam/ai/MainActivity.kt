package com.tricam.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var provider: ProcessCameraProvider? = null
    private var lens = CameraSelector.LENS_FACING_BACK
    private var flashOn = false
    private var currentZoom = 1f

    private enum class Style { SAMSUNG, PIXEL, IPHONE }
    private var style = Style.SAMSUNG

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)

        findViewById<TextView>(R.id.modeS).setOnClickListener { select(Style.SAMSUNG) }
        findViewById<TextView>(R.id.modeG).setOnClickListener { select(Style.PIXEL) }
        findViewById<TextView>(R.id.modeApple).setOnClickListener { select(Style.IPHONE) }
        findViewById<TextView>(R.id.switchCamera).setOnClickListener { switchCamera() }
        findViewById<TextView>(R.id.shutter).setOnClickListener { takePhoto() }
        findViewById<TextView>(R.id.flash).setOnClickListener { toggleFlash() }

        findViewById<TextView>(R.id.zoom05).setOnClickListener { setZoom(.5f) }
        findViewById<TextView>(R.id.zoom1).setOnClickListener { setZoom(1f) }
        findViewById<TextView>(R.id.zoom2).setOnClickListener { setZoom(2f) }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permission.launch(Manifest.permission.CAMERA)

        select(Style.SAMSUNG)
    }

    private fun select(s: Style) {
        style = s
        val title = findViewById<TextView>(R.id.modeTitle)
        val night = findViewById<TextView>(R.id.modeNight)
        val photo = findViewById<TextView>(R.id.modePhoto)
        val portrait = findViewById<TextView>(R.id.modePortrait)

        when (s) {
            Style.SAMSUNG -> {
                title.text = "SAMSUNG STYLE"
                night.text = "NIGHT"
                photo.text = "PHOTO"
                portrait.text = "PORTRAIT"
            }
            Style.PIXEL -> {
                title.text = "PIXEL STYLE"
                night.text = "NIGHT SIGHT"
                photo.text = "CAMERA"
                portrait.text = "PORTRAIT"
            }
            Style.IPHONE -> {
                title.text = "IPHONE STYLE"
                night.text = "NIGHT"
                photo.text = "PHOTO"
                portrait.text = "PORTRAIT"
            }
        }
        highlightModeButtons()
    }

    private fun highlightModeButtons() {
        val ids = intArrayOf(R.id.modeS, R.id.modeG, R.id.modeApple)
        ids.forEach { findViewById<TextView>(it).alpha = 0.55f }
        findViewById<TextView>(when (style) {
            Style.SAMSUNG -> R.id.modeS
            Style.PIXEL -> R.id.modeG
            Style.IPHONE -> R.id.modeApple
        }).alpha = 1f
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            val previewUseCase = Preview.Builder().build().also {
                it.surfaceProvider = preview.surfaceProvider
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setJpegQuality(95)
                .build()

            val selector = CameraSelector.Builder().requireLensFacing(lens).build()
            try {
                provider?.unbindAll()
                camera = provider?.bindToLifecycle(this, selector, previewUseCase, imageCapture)
                currentZoom = 1f
                camera?.cameraControl?.setLinearZoom(0f)
            } catch (_: Exception) {
                // Unsupported lens/configuration: keep the app alive instead of crashing.
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun switchCamera() {
        lens = if (lens == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        flashOn = false
        startCamera()
    }

    private fun toggleFlash() {
        flashOn = !flashOn
        imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        findViewById<TextView>(R.id.flash).alpha = if (flashOn) 1f else .65f
    }

    private fun setZoom(requested: Float) {
        val c = camera ?: return
        val state = c.cameraInfo.zoomState.value ?: return
        val minZoom = state.minZoomRatio
        val maxZoom = state.maxZoomRatio
        val z = min(max(requested, minZoom), maxZoom)
        currentZoom = z
        c.cameraControl.setZoomRatio(z)
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        capture.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF

        val name = "TriCam_${style.name.lowercase()}_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TriCamAI")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()

        capture.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                findViewById<TextView>(R.id.saveStatus).apply {
                    text = "✓ Saved"
                    visibility = View.VISIBLE
                    postDelayed({ visibility = View.GONE }, 900)
                }
            }
            override fun onError(exception: ImageCaptureException) {
                findViewById<TextView>(R.id.saveStatus).apply {
                    text = "Capture failed"
                    visibility = View.VISIBLE
                    postDelayed({ visibility = View.GONE }, 1200)
                }
            }
        })
    }
}
