package com.tricam.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private var imageCapture: ImageCapture? = null
    private var lens = CameraSelector.LENS_FACING_BACK
    private var provider: ProcessCameraProvider? = null

    private enum class Style { SAMSUNG, PIXEL, IPHONE }
    private var style = Style.SAMSUNG

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startCamera() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        findViewById<TextView>(R.id.modeS).setOnClickListener { select(Style.SAMSUNG) }
        findViewById<TextView>(R.id.modeG).setOnClickListener { select(Style.PIXEL) }
        findViewById<TextView>(R.id.modeApple).setOnClickListener { select(Style.IPHONE) }
        findViewById<TextView>(R.id.switchCamera).setOnClickListener { lens = if (lens == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK; startCamera() }
        findViewById<TextView>(R.id.shutter).setOnClickListener { takePhoto() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() else permission.launch(Manifest.permission.CAMERA)
        select(Style.SAMSUNG)
    }

    private fun select(s: Style) {
        style = s
        findViewById<TextView>(R.id.modeTitle).text = when (s) { Style.SAMSUNG -> "SAMSUNG STYLE"; Style.PIXEL -> "PIXEL STYLE"; Style.IPHONE -> "IPHONE STYLE" }
        // These are starting profiles, not proprietary Samsung/Google/Apple algorithms.
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            val p = Preview.Builder().build().also { it.surfaceProvider = preview.surfaceProvider }
            imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            val selector = CameraSelector.Builder().requireLensFacing(lens).build()
            try {
                provider?.unbindAll()
                provider?.bindToLifecycle(this, selector, p, imageCapture)
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val name = "TriCam_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TriCamAI") }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {}
            override fun onError(exception: ImageCaptureException) {}
        })
    }
}
