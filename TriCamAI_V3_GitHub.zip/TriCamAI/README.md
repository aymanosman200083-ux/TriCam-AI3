# TriCam AI — V3

Android camera project targeted at Samsung Galaxy Note 10+ Snapdragon (SM-N975U1), Android 12.

## Current build
- CameraX preview and photo capture
- Front/back camera switching
- S / G / Apple mode selector
- GitHub Actions build that produces `app-debug.apk`
- No root required

## GitHub → APK (phone friendly)
1. Create a GitHub repository named `TriCamAI`.
2. Upload the **contents** of this folder, not the ZIP file itself.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build TriCam AI APK**.
6. If it did not start automatically, press **Run workflow**.
7. Wait for the green **Success** result.
8. Open the successful run and scroll to **Artifacts**.
9. Download `TriCamAI-debug-apk` and extract it.
10. Install `app-debug.apk` on the Note 10+.

## Important
The S/G/Apple profiles are original, inspired implementations. They do not copy proprietary Samsung, Google, or Apple source code or algorithms.

## Next development stage
- Real mode-specific camera UI
- Capability-aware lens/zoom detection
- HDR-like processing
- Night processing
- Portrait/depth processing
- Note 10+ Snapdragon tuning
